
package com.mycompany.problema2;


import java.util.Scanner;
class Pila {
    private int[] elementos;
    private int capacidad;
    private int tope;

    public Pila(int capacidad) {
        this.capacidad = capacidad;
        this.elementos = new int[capacidad];
        this.tope = -1;  // Pila vacía
    }

    public boolean estaVacia() {
        return tope == -1;
    }

    public void apilar(int elemento) {
        if (tope < capacidad - 1) {
            elementos[++tope] = elemento;
        } else {
            System.out.println("La pila esta llena");
        }
    }

    public int desapilar() {
        if (!estaVacia()) {
            return elementos[tope--];
        } else {
            System.out.println("La pila esta vacía");
            return -1;
        }
    }

    public void imprimirInvertidoRecursivo() {
        if (!estaVacia()) {
            int elemento = desapilar();
            imprimirInvertidoRecursivo();
            System.out.println(elemento);
        }
    }
}

public class d2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Introduce la capacidad de la pila: ");
        int capacidad = sc.nextInt();
        
        Pila pila = new Pila(capacidad);
       
        System.out.print("Introduce los valores de la pila separados por espacios: ");
        sc.nextLine();
        String[] valores = sc.nextLine().split(" ");
        

        for (String valor : valores) {
            pila.apilar(Integer.parseInt(valor));
        }
        System.out.println("Valores de la pila invertidos:");
        pila.imprimirInvertidoRecursivo();
        
        sc.close();
    }
}