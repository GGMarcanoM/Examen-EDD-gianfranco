
package com.mycompany.eje3;

import java.util.Scanner;

public class Eje3 {
       public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ListaCircular lista = new ListaCircular();

        System.out.println("Ingrese palabras para la lista circular (ingrese 'fin' para terminar):");
        String palabra;
        do {
            palabra = sc.nextLine().trim();
            if (!palabra.equalsIgnoreCase("fin")) {
                lista.encolar(palabra);
            }
        } while (!palabra.equalsIgnoreCase("fin"));

        String resultado = lista.concatenar();
        System.out.println("Cadena resultante: " + resultado);

        sc.close();
    }
}

class Nodo {
    String palabra;
    Nodo siguiente;

    public Nodo(String palabra) {
        this.palabra = palabra;
        this.siguiente = null;
    }
}

class ListaCircular {
    Nodo cabeza;

    public ListaCircular() {
        cabeza = null;
    }

    public void encolar(String palabra) {
        Nodo nuevoNodo = new Nodo(palabra);
        if (cabeza == null) {
            cabeza = nuevoNodo;
            cabeza.siguiente = cabeza;
        } else {
            Nodo temp = cabeza;
            while (temp.siguiente != cabeza) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevoNodo;
            nuevoNodo.siguiente = cabeza;
        }
    }

    public String concatenar() {
        if (cabeza == null) {
            return "";
        }
        StringBuilder resultado = new StringBuilder();
        Nodo actual = cabeza;
        do {
            resultado.append(actual.palabra).append(" ");
            actual = actual.siguiente;
        } while (actual != cabeza);
        if (resultado.length() > 0) {
            resultado.setLength(resultado.length() - 1);
        }
        return resultado.toString();
    }
}
    

