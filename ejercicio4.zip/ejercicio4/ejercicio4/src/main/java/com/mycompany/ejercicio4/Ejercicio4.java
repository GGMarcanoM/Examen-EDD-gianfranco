
package com.mycompany.ejercicio4;

import java.util.Scanner;

public class Ejercicio4 {
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
        System.out.print("Ingresa un número para calcular su factorial: ");
        int numFactorial = sc.nextInt();

        System.out.print("Ingresa la base para la potencia: ");
        int basePotencia = sc.nextInt();
        System.out.print("Ingresa el exponente para  la potencia: ");
        int exponentePotencia = sc.nextInt();

        int factorial = Factorial(numFactorial);
        int potencia = Potencia(basePotencia, exponentePotencia);

        int resultado = factorial * potencia;


        System.out.println("El factorial de " + numFactorial + " multiplicado por " + basePotencia + "^" + exponentePotencia + " es: " + resultado);

        sc.close();
    }
    public static int Factorial(int n) {
        if (n == 0) {
            return 1;
        }
        else {
            return n * Factorial(n - 1);
        }
    }


    public static int Potencia(int base, int exponente) {

        if (exponente == 0) {
            return 1;
        }
        else {
            return base * Potencia(base, exponente - 1);
        }
    }
}
    
    
    

